import { useState, useEffect } from "react";

interface LoyaltyCardProps {
  storeName: string;
  maxStamps: number;
}

interface PrizeData {
  code: string;
  title: string;
  description: string;
}

export default function LoyaltyCard({ storeName, maxStamps }: LoyaltyCardProps) {
  const [stamps, setStamps] = useState<number>(0);
  const [showPrize, setShowPrize] = useState<boolean>(false);
  const [prizeData, setPrizeData] = useState<PrizeData | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  // Load stamps from localStorage on component mount
  useEffect(() => {
    const savedStamps = localStorage.getItem(`loyaltyCard_${storeName}_stamps`);
    if (savedStamps) {
      const parsedStamps = parseInt(savedStamps, 10);
      setStamps(parsedStamps);
      
      // Check if user already won and show prize if needed
      if (parsedStamps >= maxStamps) {
        const savedPrize = localStorage.getItem(`loyaltyCard_${storeName}_prize`);
        if (savedPrize) {
          setPrizeData(JSON.parse(savedPrize));
          setShowPrize(true);
        }
      }
    }
  }, [storeName, maxStamps]);

  // Save stamps to localStorage whenever stamps change
  // TODO: Replace localStorage with backend API call to save user progress
  // Example: await fetch('/api/user/stamps', { method: 'POST', body: JSON.stringify({ stamps }) })
  useEffect(() => {
    localStorage.setItem(`loyaltyCard_${storeName}_stamps`, stamps.toString());
  }, [stamps, storeName]);

  // Generate random prize code
  const generatePrizeCode = (): string => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  };

  // Handle play button click
  const handlePlay = async () => {
    if (stamps >= maxStamps) return;
    
    setIsPlaying(true);
    
    // Simulate game/loading delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const newStamps = stamps + 1;
    setStamps(newStamps);
    
    // Check if user won (reached max stamps)
    if (newStamps >= maxStamps) {
      const prize: PrizeData = {
        code: generatePrizeCode(),
        title: "¡Felicitaciones!",
        description: "Has completado tu tarjeta de fidelización"
      };
      
      setPrizeData(prize);
      setShowPrize(true);
      
      // TODO: Replace localStorage with backend API call to save prize
      // Example: await fetch('/api/user/prize', { method: 'POST', body: JSON.stringify(prize) })
      localStorage.setItem(`loyaltyCard_${storeName}_prize`, JSON.stringify(prize));
    }
    
    setIsPlaying(false);
  };

  const resetCard = () => {
    setStamps(0);
    setShowPrize(false);
    setPrizeData(null);
    localStorage.removeItem(`loyaltyCard_${storeName}_stamps`);
    localStorage.removeItem(`loyaltyCard_${storeName}_prize`);
  };

  const progress = (stamps / maxStamps) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Main Card */}
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-8 py-6 text-white">
            <h1 className="text-2xl font-bold text-center">{storeName}</h1>
            <p className="text-indigo-100 text-center mt-2">Tarjeta de Fidelización</p>
          </div>

          {/* Card Content */}
          <div className="p-8">
            {/* Progress Section */}
            <div className="text-center mb-8">
              <div className="text-4xl font-bold text-gray-800 mb-2">
                {stamps}/{maxStamps}
              </div>
              <p className="text-gray-600 mb-4">Sellos conseguidos</p>
              
              {/* Progress Bar */}
              <div className="w-full bg-gray-200 rounded-full h-3 mb-6">
                <div 
                  className="bg-gradient-to-r from-indigo-500 to-purple-500 h-3 rounded-full transition-all duration-500 ease-out"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>

            {/* Stamps Visualization */}
            <div className="grid grid-cols-5 gap-3 mb-8">
              {[...Array(maxStamps)].map((_, index) => (
                <div
                  key={index}
                  className={`aspect-square rounded-full border-2 flex items-center justify-center transition-all duration-300 ${
                    index < stamps
                      ? 'bg-gradient-to-br from-indigo-500 to-purple-500 border-indigo-500 text-white shadow-lg transform scale-110'
                      : 'bg-gray-100 border-gray-300 text-gray-400'
                  }`}
                >
                  {index < stamps ? (
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  ) : (
                    <span className="text-xs font-semibold">{index + 1}</span>
                  )}
                </div>
              ))}
            </div>

            {/* Action Button */}
            {stamps < maxStamps ? (
              <button
                onClick={handlePlay}
                disabled={isPlaying}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 disabled:from-gray-400 disabled:to-gray-500 text-white font-bold py-4 px-6 rounded-2xl transition-all duration-200 transform hover:scale-105 disabled:scale-100 disabled:cursor-not-allowed shadow-lg"
              >
                {isPlaying ? (
                  <div className="flex items-center justify-center gap-3">
                    <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                    Jugando...
                  </div>
                ) : (
                  '🎮 Jugar para ganar sello'
                )}
              </button>
            ) : (
              <div className="text-center">
                <div className="text-green-600 font-bold text-lg mb-4">
                  🎉 ¡Tarjeta Completa!
                </div>
                <button
                  onClick={resetCard}
                  className="bg-gray-500 hover:bg-gray-600 text-white font-semibold py-3 px-6 rounded-xl transition-colors duration-200"
                >
                  Reiniciar Tarjeta
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Prize Modal */}
        {showPrize && prizeData && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-3xl shadow-2xl max-w-sm w-full mx-4 overflow-hidden animate-pulse">
              <div className="bg-gradient-to-r from-green-500 to-emerald-500 px-6 py-4 text-white text-center">
                <h2 className="text-2xl font-bold">{prizeData.title}</h2>
              </div>
              
              <div className="p-8 text-center">
                <div className="text-6xl mb-4">🏆</div>
                <p className="text-gray-700 mb-6">{prizeData.description}</p>
                
                <div className="bg-gray-100 rounded-xl p-4 mb-6">
                  <p className="text-sm text-gray-600 mb-2">Código del premio:</p>
                  <div className="text-2xl font-bold text-gray-800 tracking-wider">
                    {prizeData.code}
                  </div>
                </div>
                
                <div className="text-sm text-gray-500 mb-6">
                  {/* TODO: Add backend integration for prize redemption */}
                  Presenta este código en la tienda para reclamar tu premio
                </div>
                
                <button
                  onClick={() => setShowPrize(false)}
                  className="bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-8 rounded-xl transition-colors duration-200"
                >
                  ¡Genial!
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
