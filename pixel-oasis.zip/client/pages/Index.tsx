import LoyaltyCard from "../components/LoyaltyCard";

export default function Index() {
  // TODO: Replace with dynamic store data from backend
  // Example: const storeData = await fetch('/api/store/config')
  const storeName = "Café Central";
  const maxStamps = 10;

  return (
    <LoyaltyCard 
      storeName={storeName} 
      maxStamps={maxStamps} 
    />
  );
}
